"use strict";
exports.id = 552;
exports.ids = [552];
exports.modules = {

/***/ 5066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "LV": () => (/* reexport */ PageTypeId),
  "EZ": () => (/* reexport */ PostTypeId),
  "sm": () => (/* reexport */ servicePages),
  "qs": () => (/* reexport */ StatusId)
});

// UNUSED EXPORTS: PostTermTypeId

;// CONCATENATED MODULE: ./src/constants/postTermTypes.ts
var PostTermTypeId;
(function(PostTermTypeId) {
    PostTermTypeId[PostTermTypeId["Category"] = 1] = "Category";
    PostTermTypeId[PostTermTypeId["Tag"] = 2] = "Tag";
})(PostTermTypeId || (PostTermTypeId = {}));


;// CONCATENATED MODULE: ./src/constants/postTypes.ts
var PostTypeId;
(function(PostTypeId) {
    PostTypeId[PostTypeId["Blog"] = 1] = "Blog";
    PostTypeId[PostTypeId["Portfolio"] = 2] = "Portfolio";
    PostTypeId[PostTypeId["Page"] = 3] = "Page";
    PostTypeId[PostTypeId["Slider"] = 4] = "Slider";
    PostTypeId[PostTypeId["Reference"] = 5] = "Reference";
    PostTypeId[PostTypeId["Service"] = 6] = "Service";
    PostTypeId[PostTypeId["Testimonial"] = 7] = "Testimonial";
    PostTypeId[PostTypeId["Navigate"] = 8] = "Navigate";
})(PostTypeId || (PostTypeId = {}));


;// CONCATENATED MODULE: ./src/constants/status.ts
var StatusId;
(function(StatusId) {
    StatusId[StatusId["Active"] = 1] = "Active";
    StatusId[StatusId["InProgress"] = 2] = "InProgress";
    StatusId[StatusId["Pending"] = 3] = "Pending";
    StatusId[StatusId["Disabled"] = 4] = "Disabled";
    StatusId[StatusId["Banned"] = 5] = "Banned";
    StatusId[StatusId["Deleted"] = 6] = "Deleted";
})(StatusId || (StatusId = {}));


;// CONCATENATED MODULE: ./src/constants/servicePages.ts
const ServicePages = {
    auth: "auth",
    postTerm: "postTerm",
    post: "post",
    setting: "setting",
    language: "language",
    mailer: "mailer",
    view: "view",
    subscriber: "subscriber",
    component: "component",
    sitemap: "sitemap"
};
/* harmony default export */ const servicePages = (ServicePages);

;// CONCATENATED MODULE: ./src/constants/pageTypes.ts
var PageTypeId;
(function(PageTypeId) {
    PageTypeId[PageTypeId["Default"] = 1] = "Default";
    PageTypeId[PageTypeId["HomePage"] = 2] = "HomePage";
    PageTypeId[PageTypeId["Blogs"] = 3] = "Blogs";
    PageTypeId[PageTypeId["Contact"] = 4] = "Contact";
})(PageTypeId || (PageTypeId = {}));


;// CONCATENATED MODULE: ./src/constants/index.ts








/***/ }),

/***/ 9066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ api)
});

// EXTERNAL MODULE: ./src/utils/path.util.ts
var path_util = __webpack_require__(657);
// EXTERNAL MODULE: external "cross-fetch/polyfill"
var polyfill_ = __webpack_require__(4208);
;// CONCATENATED MODULE: ./src/library/api/errorCodes.ts
const errorCodes_ErrorCodes = {
    success: 0,
    incorrectData: 1,
    emptyValue: 2,
    wrongValue: 3,
    registeredValue: 4,
    sqlSyntax: 5,
    notFound: 6,
    uploadError: 7,
    notLoggedIn: 8,
    noPerm: 9,
    ipBlock: 10,
    alreadyData: 11,
    wrongEmailOrPassword: 12,
    wrongPassword: 13,
    notSameValues: 14
};
/* harmony default export */ const errorCodes = (errorCodes_ErrorCodes);

;// CONCATENATED MODULE: ./src/library/api/timeouts.ts
const Timeouts = {
    veryFast: 2500,
    fast: 5000,
    normal: 10000,
    slow: 15000,
    verySlow: 30000
};
/* harmony default export */ const timeouts = ((/* unused pure expression or super */ null && (Timeouts)));

;// CONCATENATED MODULE: ./src/library/api/result.ts

class Result {
    constructor(data = [], customData = null, status = true, message = "", errorCode = ErrorCodes.success, statusCode = 200, source = ""){
        this.data = data;
        this.customData = customData;
        this.status = status;
        this.message = message;
        this.errorCode = errorCode;
        this.statusCode = statusCode;
        this.source = source;
    }
}
/* harmony default export */ const result = ((/* unused pure expression or super */ null && (Result)));

;// CONCATENATED MODULE: ./src/library/api/index.ts





;// CONCATENATED MODULE: ./src/services/api/request.ts

//const fetch = require("cross-fetch");


class ApiRequest {
    constructor(params){
        this.params = params;
        this.result = {
            data: [],
            customData: null,
            status: true,
            message: "",
            errorCode: errorCodes.success,
            statusCode: 200,
            source: ""
        };
    }
    getApiUrl() {
        let apiUrl = path_util/* default.api */.Z.api;
        this.params.url.forEach((url)=>{
            if (url) {
                apiUrl += url + "/";
            }
        });
        console.log(apiUrl);
        return apiUrl.removeLastChar();
    }
    request(resolve) {
        let config = {
            method: this.params.method,
            body: JSON.stringify(this.params.data),
            headers: {
                "Content-Type": "application/json;charset=utf-8"
            }
        };
        let url = this.getApiUrl();
        if (config.method === "GET") {
            delete config.body;
            url = `${url}?${Object.entries(this.params.data || {}).map((e)=>e.join("=")).join("&")}`;
        }
        try {
            fetch(url, config).then((response)=>response.json()).then((response)=>{
                resolve(response);
            });
        } catch (e) {
            console.log(e);
            this.result.status = false;
            this.result.customData = e;
            resolve(this.result);
        }
    }
    init() {
        return new Promise(async (resolve)=>{
            await this.request(resolve);
        });
    }
}
/* harmony default export */ const request = (ApiRequest);

;// CONCATENATED MODULE: ./src/services/api/index.ts

const Api = {
    get (params) {
        return new Promise((resolve)=>{
            new request({
                ...params,
                method: "GET",
                async: true
            }).init().then((resData)=>{
                resolve(resData);
            });
        });
    },
    post (params) {
        return new Promise((resolve)=>{
            new request({
                ...params,
                method: "POST",
                async: true
            }).init().then((resData)=>{
                resolve(resData);
            });
        });
    },
    put (params) {
        return new Promise((resolve)=>{
            new request({
                ...params,
                method: "PUT",
                async: true
            }).init().then((resData)=>{
                resolve(resData);
            });
        });
    },
    delete (params) {
        return new Promise((resolve)=>{
            new request({
                ...params,
                method: "DELETE",
                async: true
            }).init().then((resData)=>{
                resolve(resData);
            });
        });
    }
};
/* harmony default export */ const api = (Api);


/***/ }),

/***/ 657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
let api = `${"https"}://${"api.mert-test-projects.com.tr"}${process.env.API_PORT ? `:${process.env.API_PORT}` : ""}/`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    set api (newApi){
        api = newApi;
    },
    get api () {
        return api;
    },
    uploads: {
        get images () {
            return `${api}uploads/images/`;
        },
        get flags () {
            return `${api}uploads/flags/`;
        },
        get static () {
            return `${api}uploads/static/`;
        }
    }
});


/***/ })

};
;