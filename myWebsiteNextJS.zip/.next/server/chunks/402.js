"use strict";
exports.id = 402;
exports.ids = [402];
exports.modules = {

/***/ 5402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page404)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/elements/errorCodes/404.tsx



class Component404 extends external_react_.Component {
    constructor(props){
        super(props);
    }
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: "No Found"
        });
    }
}

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/pages/404.tsx





class Page404 extends external_react_.Component {
    constructor(props){
        super(props);
    }
    render() {
        let pageData = this.props.pageData;
        let appData = this.props.appData;
        let title = `${appData.settings.seoContents?.title} | 404`;
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "robots",
                            content: "noindex, nofollow"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Component404, {
                    ...this.props
                })
            ]
        });
    }
}


/***/ })

};
;