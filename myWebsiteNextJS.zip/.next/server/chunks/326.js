"use strict";
exports.id = 326;
exports.ids = [326];
exports.modules = {

/***/ 1267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ theme_lib)
});

// EXTERNAL MODULE: ./src/services/post.service.ts
var post_service = __webpack_require__(9093);
// EXTERNAL MODULE: ./src/constants/index.ts + 5 modules
var constants = __webpack_require__(5066);
// EXTERNAL MODULE: ./src/services/api/index.ts + 5 modules
var api = __webpack_require__(9066);
;// CONCATENATED MODULE: ./src/services/component.service.ts


/* harmony default export */ const component_service = ({
    get (params) {
        return api/* default.get */.Z.get({
            url: [
                constants/* ServicePages.component */.sm.component,
                params._id?.toString()
            ],
            data: params
        });
    }
});

;// CONCATENATED MODULE: ./src/lib/theme.lib.ts



/* harmony default export */ const theme_lib = ({
    async setTools (req) {
        req.pageData.themeTools = {
            ...req.pageData.themeTools
        };
        req.pageData.themeTools.navigations = (await post_service/* default.get */.Z.get({
            statusId: constants/* StatusId.Active */.qs.Active,
            langId: req.appData.languageId,
            typeId: constants/* PostTypeId.Navigate */.EZ.Navigate
        })).data;
        const footer = (await component_service.get({
            langId: req.appData.languageId,
            elementId: "footer",
            getContents: 1
        })).data;
        req.pageData.themeTools.footer = footer.length > 0 ? footer[0] : undefined;
    },
    async setComponents (req) {
        if (req.pageData.page) {
            let components = req.pageData.page.components;
            if (components) {
                for (const component of components){
                    switch(component.elementId){
                        case "services":
                            req.pageData.services = (await post_service/* default.get */.Z.get({
                                langId: req.appData.languageId,
                                typeId: constants/* PostTypeId.Service */.EZ.Service,
                                statusId: constants/* StatusId.Active */.qs.Active
                            })).data;
                            break;
                        case "testimonials":
                            req.pageData.testimonials = (await post_service/* default.get */.Z.get({
                                langId: req.appData.languageId,
                                typeId: constants/* PostTypeId.Testimonial */.EZ.Testimonial,
                                getContents: 1,
                                statusId: constants/* StatusId.Active */.qs.Active
                            })).data;
                            break;
                        case "clients":
                            req.pageData.clients = (await post_service/* default.get */.Z.get({
                                langId: req.appData.languageId,
                                typeId: constants/* PostTypeId.Reference */.EZ.Reference,
                                statusId: constants/* StatusId.Active */.qs.Active
                            })).data;
                            break;
                    }
                }
            }
        }
    }
});


/***/ }),

/***/ 627:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

class HandleForm {
    static onChangeInput(event, component) {
        component.setState((state)=>{
            let value = null;
            if (event.target.type === "checkbox") {
                value = event.target.checked ? 1 : 0;
            } else {
                value = event.target.value;
            }
            eval(`state.formData${event.target.name.split(".").map((name)=>`['${name}']`).join("")} = value`);
            return state;
        });
    }
    static onChangeSelect(key, value, component) {
        component.setState((state)=>{
            if (Array.isArray(value)) {
                eval(`state.formData${key.split(".").map((name)=>`['${name}']`).join("")}=[]`);
                value.forEach((item)=>{
                    let data = typeof item.value !== "undefined" ? item.value : item;
                    eval(`state.formData${key.split(".").map((name)=>`['${name}']`).join("")}.push(data)`);
                });
            } else {
                eval(`state.formData${key.split(".").map((name)=>`['${name}']`).join("")} = value`);
            }
            return state;
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HandleForm);


/***/ }),

/***/ 5993:
/***/ (() => {

function convertQueryData(data) {
    return JSON.stringify({
        d: data
    });
}
Array.prototype.indexOfKey = function(key, value) {
    let findIndex = -1;
    if (typeof value !== "undefined") {
        findIndex = this.map((data)=>{
            let _data = data;
            if (typeof key === "string") {
                if (key.length > 0) {
                    for (const name of key.split(".")){
                        if (typeof _data !== "undefined") {
                            _data = _data[name];
                        }
                    }
                }
            }
            return convertQueryData(_data);
        }).indexOf(convertQueryData(value));
    }
    return findIndex;
};
Array.prototype.findSingle = function(key, value) {
    return this.find(function(data) {
        let query = false;
        if (typeof value !== "undefined") {
            let _data = data;
            if (typeof key === "string") {
                if (key.length > 0) {
                    for (const name of key.split(".")){
                        if (typeof _data !== "undefined") {
                            _data = _data[name];
                        }
                    }
                }
            }
            query = convertQueryData(_data) == convertQueryData(value);
        }
        return query;
    });
};
Array.prototype.findMulti = function(key, value, isLike = true) {
    let founds = Array();
    this.find(function(data) {
        let query = false;
        if (typeof value !== "undefined") {
            let _data = data;
            if (typeof key === "string") {
                if (key.length > 0) {
                    for (const name of key.split(".")){
                        if (typeof _data !== "undefined") {
                            _data = _data[name];
                        }
                    }
                }
            }
            if (Array.isArray(value)) {
                query = value.map((v)=>convertQueryData(v)).includes(convertQueryData(_data));
            } else {
                query = convertQueryData(_data) == convertQueryData(value);
            }
        }
        if (query === isLike) founds.push(Object.assign(data));
    });
    return founds;
};
Array.prototype.orderBy = function(key, sort_type) {
    return this.sort(function(a, b) {
        if (key !== "" && (!a.hasOwnProperty(key) || !b.hasOwnProperty(key))) {
            // property doesn't exist on either object
            return 0;
        }
        let keyA = key != "" ? a[key] : a;
        let keyB = key != "" ? b[key] : b;
        const varA = typeof keyA === "string" ? keyA.toUpperCase() : keyA;
        const varB = typeof keyB === "string" ? keyB.toUpperCase() : keyB;
        let comparison = 0;
        if (varA > varB) {
            comparison = 1;
        } else if (varA < varB) {
            comparison = -1;
        }
        return sort_type === "desc" ? comparison * -1 : comparison;
    });
};
Array.prototype.serializeObject = function() {
    let result = {};
    this.forEach((item)=>{
        result[item.name] = item.value;
    });
    return result;
};
Array.prototype.remove = function(index, deleteCount = 1) {
    this.splice(index, deleteCount);
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({});


/***/ }),

/***/ 7425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export DateMask */
var DateMask;
(function(DateMask) {
    DateMask["ALL"] = "yyyy-mm-dd HH:MM:ss";
    DateMask["UNIFIED_ALL"] = "yyyymmddHHMMss";
    DateMask["DATE"] = "yyyy-mm-dd";
})(DateMask || (DateMask = {}));
Date.prototype.addDays = function(n) {
    this.setDate(this.getDate() + n);
};
Date.prototype.nextDay = function() {
    this.addDays(1);
};
Date.prototype.addMonths = function(n) {
    this.setMonth(this.getMonth() + n);
};
Date.prototype.addYears = function(n) {
    this.setFullYear(this.getFullYear() + n);
};
Date.prototype.getStringWithMask = function(mask, utc = false) {
    let date = this;
    let i18n = {
        dayNames: [
            "Sun",
            "Mon",
            "Tue",
            "Wed",
            "Thu",
            "Fri",
            "Sat",
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        ],
        monthNames: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        ]
    };
    let token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g, timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g, timezoneClip = /[^-+\dA-Z]/g;
    function pad(val, len = 0) {
        val = String(val);
        len = len || 2;
        while(val.length < len)val = "0" + val;
        return val;
    }
    // You can't provide utc if you skip other args (use the "UTC:" mask prefix)
    if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
        mask = date;
        date = undefined;
    }
    // Passing date through Date applies Date.parse, if necessary
    date = date ? new Date(date) : new Date;
    if (isNaN(date)) throw SyntaxError("invalid date");
    // Allow setting the utc argument via the mask
    if (mask.slice(0, 4) == "UTC:") {
        mask = mask.slice(4);
        utc = true;
    }
    const _ = utc ? "getUTC" : "get", d = date[_ + "Date"](), D = date[_ + "Day"](), m = date[_ + "Month"](), y = date[_ + "FullYear"](), H = date[_ + "Hours"](), M = date[_ + "Minutes"](), s = date[_ + "Seconds"](), L = date[_ + "Milliseconds"](), o = utc ? 0 : date.getTimezoneOffset(), flags = {
        d: d,
        dd: pad(d),
        ddd: i18n.dayNames[D],
        dddd: i18n.dayNames[D + 7],
        m: m + 1,
        mm: pad(m + 1),
        mmm: i18n.monthNames[m],
        mmmm: i18n.monthNames[m + 12],
        yy: String(y).slice(2),
        yyyy: y,
        h: H % 12 || 12,
        hh: pad(H % 12 || 12),
        H: H,
        HH: pad(H),
        M: M,
        MM: pad(M),
        s: s,
        ss: pad(s),
        l: pad(L, 3),
        L: pad(L > 99 ? Math.round(L / 10) : L),
        t: H < 12 ? "a" : "p",
        tt: H < 12 ? "am" : "pm",
        T: H < 12 ? "A" : "P",
        TT: H < 12 ? "AM" : "PM",
        // @ts-ignore
        Z: utc ? "UTC" : (String(date).match(timezone) || [
            ""
        ]).pop().replace(timezoneClip, ""),
        o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
        // @ts-ignore
        S: [
            "th",
            "st",
            "nd",
            "rd"
        ][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
    };
    return mask.replace(token, function($0) {
        // @ts-ignore
        return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
    });
};
Date.prototype.diffMinutes = function(date) {
    let diff = (date.getTime() - this.getTime()) / 1000;
    diff /= 60;
    return Math.round(diff);
};
Date.prototype.diffDays = function(date) {
    let diff = (date.getTime() - this.getTime()) / 1000;
    diff /= 60 * 60 * 24;
    return Math.ceil(diff);
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({});


/***/ }),

/***/ 324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports FilterTypes, ClearTypes */
/* harmony import */ var _number__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5021);
/* harmony import */ var _string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2249);
/* harmony import */ var _array__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5993);
/* harmony import */ var _math__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5175);
/* harmony import */ var _date__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7425);





var FilterTypes;
(function(FilterTypes) {
    FilterTypes[FilterTypes["EMAIL"] = 0] = "EMAIL";
    FilterTypes[FilterTypes["INT"] = 1] = "INT";
    FilterTypes[FilterTypes["FLOAT"] = 2] = "FLOAT";
})(FilterTypes || (FilterTypes = {}));
var ClearTypes;
(function(ClearTypes) {
    ClearTypes[ClearTypes["STRING"] = 0] = "STRING";
    ClearTypes[ClearTypes["EMAIL"] = 1] = "EMAIL";
    ClearTypes[ClearTypes["INT"] = 2] = "INT";
    ClearTypes[ClearTypes["FLOAT"] = 3] = "FLOAT";
    ClearTypes[ClearTypes["SEO_URL"] = 4] = "SEO_URL";
    ClearTypes[ClearTypes["ALPHABETS"] = 5] = "ALPHABETS";
})(ClearTypes || (ClearTypes = {}));
class Variable {
    static clear(variable, type = ClearTypes.STRING, clear_html_tags = true) {
        variable = typeof variable != "undefined" ? variable : null;
        if (variable !== null) {
            variable = clear_html_tags ? variable.toString().stripTags() : variable;
            if (isNaN(variable)) {
                variable = variable.toString().trim();
            }
            switch(type){
                case ClearTypes.INT:
                    // @ts-ignore
                    variable = Number.parseInt(Variable.filterVar(variable, FilterTypes.INT));
                    break;
                case ClearTypes.FLOAT:
                    // @ts-ignore
                    variable = Number.parseFloat(Variable.filterVar(variable, FilterTypes.FLOAT));
                    break;
                case ClearTypes.ALPHABETS:
                    variable = variable.replace(/[^a-zA-ZğüşöçİĞÜŞÖÇ\w ]/g, "");
                    break;
                case ClearTypes.EMAIL:
                    variable = Variable.filterVar(variable, FilterTypes.EMAIL);
                    break;
                case ClearTypes.SEO_URL:
                    variable = variable.toString().convertSEOUrl();
                    break;
            }
        }
        return variable;
    }
    static clearAllData(data, not_column = []) {
        if (!this.isSet(()=>data)) return false;
        // @ts-ignore
        for (let [key, _1] of Object.entries(data)){
            // @ts-ignore
            if (not_column.includes(key)) continue;
            let clear_type = ClearTypes.STRING;
            if (!this.isEmpty(_1)) {
                if (typeof _1 === "object") {
                    this.clearAllData(_1);
                    continue;
                }
                if (!isNaN(Number(_1))) {
                    if (Number(_1).isInt()) clear_type = ClearTypes.INT;
                    else if (Number(_1).isFloat()) clear_type = ClearTypes.FLOAT;
                }
            }
            data[key] = this.clear(_1, clear_type, true);
        }
        return data;
    }
    static isSet(...variable) {
        let result;
        try {
            for(let i = 0; i < variable.length; i++){
                result = variable[i]();
            }
        } catch (e) {
            result = undefined;
        } finally{
            return result !== undefined;
        }
    }
    static isEmpty(...variable) {
        for(let i = 0; i < variable.length; i++){
            if (!this.isSet(()=>variable[i]) || variable[i] === null || variable[i].length === 0 || !variable[i].toString().trim()) return true;
        }
        return false;
    }
    static isNull(...variable) {
        for(let i = 0; i < variable.length; i++){
            if (variable[i] !== null) return false;
        }
        return true;
    }
    static isNotNull(...variable) {
        return !Variable.isNull(variable);
    }
    static setDefault(variable, default_value) {
        return this.isSet(variable) ? variable() : default_value;
    }
    static filterVar(variable, filter_type) {
        let regex;
        // Check Filter Type
        switch(filter_type){
            case FilterTypes.EMAIL:
                regex = /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi;
                break;
            case FilterTypes.INT:
                regex = /([0-9]+)/g;
                break;
            case FilterTypes.FLOAT:
                regex = /[+-]?([0-9]*[.])[0-9]+/g;
        }
        // Check Defined
        let match;
        if ((match = regex.exec(variable)) != null) {
            variable = match[0];
        } else {
            variable = "";
        }
        return variable;
    }
}

//import the module and enable
new Variable();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Variable);


/***/ }),

/***/ 5175:
/***/ (() => {

Math.randomCustom = function(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
};
Math.range = function(value, min, max, equal = false) {
    return equal ? value >= min && value <= max : value > min && value < max;
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({});


/***/ }),

/***/ 5021:
/***/ (() => {

Number.prototype.isInt = function() {
    if (typeof this !== "number") return false;
    let n = this;
    return Number(n) === n && n % 1 === 0;
};
Number.prototype.isFloat = function() {
    if (typeof this !== "number") return false;
    let n = this;
    return Number(n) === n && n % 1 !== 0;
};
Number.prototype.getPercent = function(min, max) {
    if (typeof this !== "number") return 0;
    return 100 * (this - min) / (max - min);
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({});


/***/ }),

/***/ 2249:
/***/ (() => {

String.createId = function() {
    let dt = new Date().getTime();
    let id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
        let r = (dt + Math.random() * 16) % 16 | 0;
        dt = Math.floor(dt / 16);
        return (c == "x" ? r : r & 0x3 | 0x8).toString(16);
    });
    return id;
};
String.prototype.replaceArray = function(find, replace) {
    let replaceString = this;
    for(let i = 0; i < find.length; i++){
        replaceString = replaceString.replaceAll(find[i], replace[i]);
    }
    return replaceString.toString();
};
String.prototype.removeLastChar = function(remove_count = 1) {
    return this.slice(0, remove_count * -1);
};
String.prototype.encode = function() {
    return encodeURIComponent(this.toString());
};
String.prototype.decode = function() {
    return decodeURIComponent(this.toString());
};
String.prototype.convertKey = function() {
    return unescape(encodeURIComponent(this.convertSEOUrl()));
};
String.prototype.stripTags = function() {
    return this.replace(/<\/?[^>]+>/gi, "");
};
String.prototype.convertSEOUrl = function() {
    let $this = this.toString();
    $this = $this.toString().toLowerCase().trim().stripTags();
    $this = $this.replace("'", "");
    let tr = Array("ş", "Ş", "ı", "I", "İ", "ğ", "Ğ", "\xfc", "\xdc", "\xf6", "\xd6", "\xc7", "\xe7", "(", ")", "/", ":", ",", "!");
    let eng = Array("s", "s", "i", "i", "i", "g", "g", "u", "u", "o", "o", "c", "c", "", "", "_", "_", "", "");
    $this = $this.replaceArray(tr, eng);
    $this = $this.replace(/[^-\w\s]/g, ""); // Remove unneeded characters
    $this = $this.replace(/^\s+|\s+$/g, ""); // Trim leading/trailing spaces
    $this = $this.replace(/[-\s]+/g, "-"); // Convert spaces to hyphens
    return $this;
};
String.prototype.toCapitalizeCase = function() {
    const arr = this.split(" ");
    for(var i = 0; i < arr.length; i++){
        arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
    }
    return arr.join(" ");
};
String.prototype.isUrl = function() {
    let url;
    try {
        url = new URL(this.toString());
    } catch (_) {
        return false;
    }
    return url.protocol === "http:" || url.protocol === "https:";
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({});


/***/ }),

/***/ 9093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9066);
/* harmony import */ var constants_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5066);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    get (params) {
        let url = Array.isArray(params.typeId) ? [] : [
            params.typeId?.toString(),
            params.postId?.toString()
        ];
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get({
            url: [
                constants_index__WEBPACK_IMPORTED_MODULE_1__/* .ServicePages.post */ .sm.post,
                ...url
            ],
            data: params
        });
    },
    updateView (params) {
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put({
            url: [
                constants_index__WEBPACK_IMPORTED_MODULE_1__/* .ServicePages.post */ .sm.post,
                "view",
                params.typeId.toString(),
                params.postId.toString()
            ],
            data: params
        });
    }
});


/***/ }),

/***/ 394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var library_variable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(324);
/* harmony import */ var _path_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(657);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getUploadedImageSrc (imageName, uploadPaths = _path_util__WEBPACK_IMPORTED_MODULE_1__/* ["default"].uploads */ .Z.uploads) {
        return imageName && !library_variable__WEBPACK_IMPORTED_MODULE_0__/* ["default"].isEmpty */ .ZP.isEmpty(imageName) ? imageName.isUrl() ? imageName : uploadPaths.images + imageName : uploadPaths.static + "empty.jpg";
    }
});


/***/ })

};
;