"use strict";
exports.id = 199;
exports.ids = [199];
exports.modules = {

/***/ 2199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    home (data) {
        return data.apiPath.website.base;
    },
    language (language) {
        return `${language.shortKey}-${language.locale}`;
    },
    languageUpperLocale (language) {
        return `${language.shortKey}_${language.locale.toUpperCase()}`;
    },
    target (data, target) {
        let path = `${data.apiPath.website.base}`;
        if (data.languageId != data.settings.defaultLangId) {
            const language = data.languages.findSingle("_id", data.languageId);
            if (language) {
                path = `${data.apiPath.website.base}/${this.language(language)}`;
            }
        }
        if (target.search("/") > -1 || target.search("/") === -1 && target.search("#") === -1) {
            target = `/${target}`;
        }
        path += target;
        return path;
    },
    changeLanguage (appData, language) {
        let path = "";
        if (appData.languageId != appData.settings.defaultLangId) {
            path = appData.apiPath.website.full.replace(appData.languageKeyWithLocale ?? "", this.language(language));
        } else {
            path = `${appData.apiPath.website.base}/${this.language(language)}${appData.apiPath.website.originalUrl}`.replace(/\/$/, "");
        }
        return path;
    }
});


/***/ })

};
;