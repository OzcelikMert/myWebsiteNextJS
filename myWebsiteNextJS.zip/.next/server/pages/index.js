"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7587:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ComponentCarousel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_functions_imageSource_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(394);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);





class ComponentCarousel extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    constructor(props){
        super(props);
    }
    Item = (props)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "masthead",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                    src: utils_functions_imageSource_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getUploadedImageSrc */ .Z.getUploadedImageSrc(props.contents?.image),
                    alt: props.contents?.title ?? "",
                    width: 1250,
                    height: 1024
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "masthead-filter"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center masthead-content-container",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "masthead-content d-flex justify-content-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "mx-auto my-0 text-uppercase mb-5 fw-bold",
                                    children: props.contents?.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-white mx-auto mt-2 mb-5",
                                    children: props.contents?.shortContent
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "buttons",
                                    children: props.contents?.buttons?.map((button)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: button.url,
                                            className: "btn-get-started scrollto",
                                            children: button.title
                                        }))
                                })
                            ]
                        })
                    })
                })
            ]
        });
    };
    render() {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "intro",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_3__.Carousel, {
                showArrows: false,
                emulateTouch: true,
                showThumbs: false,
                showStatus: false,
                renderIndicator: ()=>null,
                children: this.props.pageData?.sliders.map((slider)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(this.Item, {
                        ...slider
                    }))
            })
        });
    }
}


/***/ }),

/***/ 5970:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PageHome),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_elements_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7587);
/* harmony import */ var components_elements_selectedComponents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3737);
/* harmony import */ var services_post_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9093);
/* harmony import */ var constants_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5066);
/* harmony import */ var lib_view_lib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1482);
/* harmony import */ var lib_theme_lib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1267);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_elements_selectedComponents__WEBPACK_IMPORTED_MODULE_3__]);
components_elements_selectedComponents__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









class PageHome extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    constructor(props){
        super(props);
    }
    render() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_elements_carousel__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    ...this.props
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_elements_selectedComponents__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    ...this.props
                })
            ]
        });
    }
}
async function getServerSideProps(context) {
    let req = context.req;
    let pages = (await services_post_service__WEBPACK_IMPORTED_MODULE_4__/* ["default"].get */ .Z.get({
        langId: req.appData.languageId,
        typeId: constants_index__WEBPACK_IMPORTED_MODULE_5__/* .PostTypeId.Page */ .EZ.Page,
        getContents: 1,
        pageTypeId: constants_index__WEBPACK_IMPORTED_MODULE_5__/* .PageTypeId.HomePage */ .LV.HomePage,
        statusId: constants_index__WEBPACK_IMPORTED_MODULE_5__/* .StatusId.Active */ .qs.Active
    })).data;
    let page = pages.length > 0 ? pages[0] : null;
    if (page) {
        req.pageData.page = page;
        await lib_view_lib__WEBPACK_IMPORTED_MODULE_6__/* ["default"].set */ .Z.set(req);
        req.pageData.sliders = req.pageData.page.pageTypeId == constants_index__WEBPACK_IMPORTED_MODULE_5__/* .PageTypeId.HomePage */ .LV.HomePage ? (await services_post_service__WEBPACK_IMPORTED_MODULE_4__/* ["default"].get */ .Z.get({
            langId: req.appData.languageId,
            typeId: constants_index__WEBPACK_IMPORTED_MODULE_5__/* .PostTypeId.Slider */ .EZ.Slider,
            statusId: constants_index__WEBPACK_IMPORTED_MODULE_5__/* .StatusId.Active */ .qs.Active
        })).data : [];
        await lib_theme_lib__WEBPACK_IMPORTED_MODULE_7__/* ["default"].setComponents */ .Z.setComponents(req);
    }
    return {
        props: {
            pageData: req.pageData
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4208:
/***/ ((module) => {

module.exports = require("cross-fetch/polyfill");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 4753:
/***/ ((module) => {

module.exports = require("react-tsparticles");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3047:
/***/ ((module) => {

module.exports = require("tsparticles");

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5549:
/***/ ((module) => {

module.exports = import("react-slider");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,552,326,562], () => (__webpack_exec__(5970)));
module.exports = __webpack_exports__;

})();