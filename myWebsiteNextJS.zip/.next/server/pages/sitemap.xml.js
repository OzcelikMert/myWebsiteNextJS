"use strict";
(() => {
var exports = {};
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 6270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PageSitemapXML),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(855);
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(xml2js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_sitemap_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8015);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function PageSitemapXML() {
    return null;
}
async function getServerSideProps(context) {
    let res = context.res;
    let name = "sitemap";
    let resData = await services_sitemap_service__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get({
        name: name
    });
    let xml = new (xml2js__WEBPACK_IMPORTED_MODULE_0___default().Builder)().buildObject(resData.data);
    res.setHeader("Content-Type", "text/xml");
    res.write(xml);
    res.end();
    return {
        props: {}
    };
}


/***/ }),

/***/ 8015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9066);
/* harmony import */ var constants_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5066);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    get (params) {
        let name = Array.isArray(params.name) ? [] : [
            params.name
        ];
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get({
            url: [
                constants_index__WEBPACK_IMPORTED_MODULE_1__/* .ServicePages.sitemap */ .sm.sitemap,
                ...name
            ],
            data: params
        });
    }
});


/***/ }),

/***/ 4208:
/***/ ((module) => {

module.exports = require("cross-fetch/polyfill");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 855:
/***/ ((module) => {

module.exports = require("xml2js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [552], () => (__webpack_exec__(6270)));
module.exports = __webpack_exports__;

})();