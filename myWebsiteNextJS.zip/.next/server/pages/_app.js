(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,197];
exports.modules = {

/***/ 8046:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/assets/styles/global.scss
var global = __webpack_require__(2202);
// EXTERNAL MODULE: ./src/library/variable/array.ts
var array = __webpack_require__(5993);
// EXTERNAL MODULE: ./src/library/variable/string.ts
var string = __webpack_require__(2249);
// EXTERNAL MODULE: ./src/library/variable/number.ts
var number = __webpack_require__(5021);
// EXTERNAL MODULE: ./src/library/variable/date.ts
var date = __webpack_require__(7425);
// EXTERNAL MODULE: ./src/library/variable/math.ts
var math = __webpack_require__(5175);
// EXTERNAL MODULE: ./src/library/variable/index.ts
var variable = __webpack_require__(324);
// EXTERNAL MODULE: ./src/utils/functions/imageSource.util.ts
var imageSource_util = __webpack_require__(394);
// EXTERNAL MODULE: ./src/utils/functions/link.util.ts
var link_util = __webpack_require__(2199);
;// CONCATENATED MODULE: ./src/components/head/index.tsx






class ComponentHead extends external_react_.Component {
    constructor(props){
        super(props);
    }
    get getKeywords() {
        let terms = [];
        if (this.props.pageData.page && this.props.pageData.page.terms.length > 0) {
            terms = this.props.pageData.page.terms.map((term)=>term?.contents.title).filter((term)=>term);
        } else if (this.props.appData.settings.seoContents?.tags && this.props.appData.settings.seoContents.tags.length > 0) {
            terms = this.props.appData.settings.seoContents.tags;
        }
        return terms.join(",");
    }
    get getAlternates() {
        return this.props.pageData.page?.alternates?.map((alternate)=>{
            let language = this.props.appData.languages.findSingle("_id", alternate.langId);
            if (language) {
                return /*#__PURE__*/ jsx_runtime_.jsx("link", {
                    rel: "alternate",
                    hrefLang: link_util/* default.language */.Z.language(language),
                    href: link_util/* default.changeLanguage */.Z.changeLanguage(this.props.appData, language)
                });
            }
        });
    }
    get getFacebookAlternates() {
        return this.props.pageData.page?.alternates?.map((alternate)=>{
            let language = this.props.appData.languages.findSingle("_id", alternate.langId);
            if (language) {
                return /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:locale:alternate",
                    content: link_util/* default.languageUpperLocale */.Z.languageUpperLocale(language)
                });
            }
        });
    }
    render() {
        let pageData = this.props.pageData;
        let appData = this.props.appData;
        let title = `${appData.settings.seoContents?.title}${!variable/* default.isEmpty */.ZP.isEmpty(pageData.page?.contents?.title) ? ` | ${pageData.page?.contents?.title}` : ""}`;
        let desc = pageData.page?.contents?.seoContent || appData.settings.seoContents?.content || "";
        let logo = imageSource_util/* default.getUploadedImageSrc */.Z.getUploadedImageSrc(appData.settings.logo, appData.apiPath.uploads);
        let language = this.props.appData.languages.findSingle("_id", this.props.appData.languageId);
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "description",
                    content: desc
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "copyright",
                    content: appData.settings.seoContents?.title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "author",
                    content: "\xd6z\xe7elik Software"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "keywords",
                    content: this.getKeywords
                }),
                this.getAlternates,
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    itemProp: "name",
                    content: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    itemProp: "description",
                    content: desc
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    itemProp: "image",
                    content: logo
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:type",
                    content: "website"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:title",
                    content: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:url",
                    content: appData.apiPath.website.full
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:description",
                    content: desc
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:site_name",
                    content: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:image",
                    content: logo
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    property: "og:locale",
                    content: language ? link_util/* default.languageUpperLocale */.Z.languageUpperLocale(language) : ""
                }),
                this.getFacebookAlternates,
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "twitter:card",
                    content: "summary_large_image"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "twitter:title",
                    content: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "twitter:url",
                    content: appData.apiPath.website.full
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "twitter:description",
                    content: desc
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "twitter:image",
                    content: logo
                })
            ]
        });
    }
}

// EXTERNAL MODULE: ./src/pages/404.tsx + 1 modules
var _404 = __webpack_require__(5402);
;// CONCATENATED MODULE: ./src/components/providers/noFound.tsx



class ProviderNoFound extends external_react_.Component {
    constructor(props){
        super(props);
    }
    render() {
        return this.props.pageData && this.props.pageData.page ? this.props.children : /*#__PURE__*/ jsx_runtime_.jsx(_404["default"], {
            ...this.props
        });
    }
}

;// CONCATENATED MODULE: external "cookies-next"
const external_cookies_next_namespaceObject = require("cookies-next");
;// CONCATENATED MODULE: ./src/lib/cookie.lib.ts

/* harmony default export */ const cookie_lib = ({
    set (req) {
        req.appData.cookies = {
            ...req.appData.cookies,
            ...req.cookies
        };
    },
    setLanguageId (req, res) {
        (0,external_cookies_next_namespaceObject.setCookie)("languageId", req.appData.languageId, {
            req,
            res,
            maxAge: 1000 * 60 * 60 * 24 * 365,
            httpOnly: true,
            path: "/"
        });
    }
});

// EXTERNAL MODULE: ./src/utils/path.util.ts
var path_util = __webpack_require__(657);
;// CONCATENATED MODULE: external "next-absolute-url"
const external_next_absolute_url_namespaceObject = require("next-absolute-url");
var external_next_absolute_url_default = /*#__PURE__*/__webpack_require__.n(external_next_absolute_url_namespaceObject);
;// CONCATENATED MODULE: ./src/lib/path.lib.ts


/* harmony default export */ const path_lib = ({
    set (req) {
        let paths = external_next_absolute_url_default()(req);
        req.appData.apiPath = {
            website: {
                full: `${paths.protocol}//${paths.host}${req.url !== "/" ? `${req.url}` : ""}`.replace(/\/$/, ""),
                base: `${paths.protocol}//${paths.host}`,
                originalUrl: req.url !== "/" ? `${req.url}` : ""
            },
            ...path_util/* default */.Z
        };
    }
});

// EXTERNAL MODULE: ./src/services/api/index.ts + 5 modules
var api = __webpack_require__(9066);
// EXTERNAL MODULE: ./src/constants/index.ts + 5 modules
var constants = __webpack_require__(5066);
;// CONCATENATED MODULE: ./src/services/language.service.ts


/* harmony default export */ const language_service = ({
    get (params) {
        return api/* default.get */.Z.get({
            url: [
                constants/* ServicePages.language */.sm.language
            ],
            data: params
        });
    }
});

;// CONCATENATED MODULE: ./src/lib/language.lib.ts


/* harmony default export */ const language_lib = ({
    async set (req) {
        req.appData.languages = (await language_service.get({})).data;
    },
    check (req, res, langKey) {
        let languages = req.appData.languages.findMulti("shortKey", langKey.removeLastChar(3));
        let language = languages.findSingle("locale", langKey.slice(3));
        if (language) {
            req.appData.languageId = language._id;
            req.appData.languageKeyWithLocale = link_util/* default.language */.Z.language(language);
        } else {
            res.writeHead(404, {
                Location: "/404"
            });
            return true;
        }
        return false;
    },
    isDefault (req, res) {
        if (req.appData.languageId == req.appData.settings.defaultLangId) {
            res.writeHead(302, {
                Location: req.appData.apiPath.website.full.replace(`${req.appData.apiPath.website.base}/${req.appData.languageKeyWithLocale}`, `${req.appData.apiPath.website.base}`)
            });
            res.end();
            return true;
        }
        return false;
    },
    checkCookie (req, res) {
        if (req.appData.cookies.languageId) {
            if (req.appData.settings.defaultLangId != req.appData.cookies.languageId) {
                const language = req.appData.languages.findSingle("_id", req.appData.cookies.languageId);
                if (language) {
                    res.writeHead(302, {
                        Location: req.appData.apiPath.website.full.replace(req.appData.apiPath.website.base, `${req.appData.apiPath.website.base}/${link_util/* default.language */.Z.language(language)}`)
                    });
                    res.end();
                    return true;
                }
            }
        }
        return false;
    }
});

;// CONCATENATED MODULE: ./src/services/setting.service.ts


/* harmony default export */ const setting_service = ({
    get (params) {
        return api/* default.get */.Z.get({
            url: [
                constants/* ServicePages.setting */.sm.setting
            ],
            data: params
        });
    }
});

;// CONCATENATED MODULE: ./src/lib/setting.lib.ts


/* harmony default export */ const setting_lib = ({
    async set (req) {
        req.appData.settings = (await setting_service.get({
            ...req.appData.languageId ? {
                langId: req.appData.languageId
            } : {}
        })).data[0];
    },
    async setDefaultLanguageId (req) {
        req.appData.settings = (await setting_service.get({
            onlyDefaultLanguageId: true
        })).data[0];
        if (variable/* default.isEmpty */.ZP.isEmpty(req.appData.languageId)) {
            req.appData.languageId = req.appData.settings.defaultLangId;
        }
    }
});

// EXTERNAL MODULE: ./src/lib/theme.lib.ts + 1 modules
var theme_lib = __webpack_require__(1267);
;// CONCATENATED MODULE: ./src/components/tools/navbar.tsx





class Navbar extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            isNavbarSticky: false
        };
    }
    componentDidMount() {
        this.setEvents();
    }
    componentWillUnmount() {
        this.clearEvents();
    }
    setEvents() {
        window.addEventListener("scroll", ()=>this.handleScroll());
    }
    clearEvents() {
        window.removeEventListener("scroll", ()=>this.handleScroll());
    }
    handleScroll() {
        if (window.scrollY > 100) {
            if (!this.state.isNavbarSticky) {
                this.setState({
                    isNavbarSticky: true
                });
            }
        } else {
            if (this.state.isNavbarSticky) {
                this.setState({
                    isNavbarSticky: false
                });
            }
        }
    }
    getNavElement = (nav, mainId)=>{
        if (nav.mainId?._id != mainId) return null;
        let subNav = this.props.pageData.themeTools.navigations.findMulti("mainId._id", nav._id);
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            className: subNav.length == 0 ? "nav-item nav-link" : "nav-item nav-link drop-down",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: subNav.length == 0 ? link_util/* default.target */.Z.target(this.props.appData, nav.contents?.url || "") : "javascript:void(0);",
                    children: nav.contents?.title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    children: subNav.map((_subNav)=>this.getNavElement(_subNav, nav._id))
                })
            ]
        });
    };
    GetLanguagesElement = ()=>{
        let current = this.props.appData.languages.findSingle("_id", this.props.appData.languageId);
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            className: "nav-item nav-link drop-down",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "javascript:void(0);",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "flag-size",
                                    src: this.props.appData.apiPath.uploads.flags + current?.image,
                                    alt: current?.title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col ms-1",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: current?.shortKey.toUpperCase()
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    children: this.props.appData.languages.map((lang)=>this.props.appData.languageId == lang._id ? null : /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item nav-link",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: link_util/* default.changeLanguage */.Z.changeLanguage(this.props.appData, lang),
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-3",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "flag-size",
                                                src: this.props.appData.apiPath.uploads.flags + lang.image,
                                                alt: lang.title
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-9",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: lang.title
                                            })
                                        })
                                    ]
                                })
                            })
                        }))
                })
            ]
        });
    };
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("header", {
            id: "header",
            className: `${ false ? 0 : ""} ${this.props.pageData?.page?.pageTypeId == constants/* PageTypeId.HomePage */.LV.HomePage ? "fixed-top" : "bg-secondary"}`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "logo float-start wabbysoft_logo",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: link_util/* default.home */.Z.home(this.props.appData),
                                className: "img-fluid scrollto",
                                style:  false ? 0 : {},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    style: {
                                        filter: "drop-shadow(1px 0.5px 0.5px #fff)"
                                    },
                                    src: imageSource_util/* default.getUploadedImageSrc */.Z.getUploadedImageSrc(this.props.appData.settings.logo),
                                    alt: this.props.appData.settings.seoContents?.title,
                                    title: this.props.appData.settings.seoContents?.title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: link_util/* default.home */.Z.home(this.props.appData),
                                className: "img-fluid scrollto",
                                style:  false ? 0 : {
                                    display: "none"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    style: {
                                        filter: "drop-shadow(1px 0.5px 0.5px #fff)"
                                    },
                                    src: imageSource_util/* default.getUploadedImageSrc */.Z.getUploadedImageSrc(this.props.appData.settings.logoTwo),
                                    alt: this.props.appData.settings.seoContents?.title,
                                    title: this.props.appData.settings.seoContents?.title
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: "main-nav float-end d-none d-lg-block",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                this.props.pageData.themeTools.navigations.map((navigation)=>this.getNavElement(navigation)),
                                this.GetLanguagesElement()
                            ]
                        })
                    })
                ]
            })
        });
    }
}

;// CONCATENATED MODULE: ./src/components/tools/backToTop.tsx


class BackToTop extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            isShow: false
        };
    }
    componentDidMount() {
        if (window) this.setEvents();
    }
    componentWillUnmount() {
        if (window) this.clearEvents();
    }
    setEvents() {
        window.addEventListener("scroll", ()=>this.handleScroll());
    }
    clearEvents() {
        window.removeEventListener("scroll", ()=>this.handleScroll());
    }
    handleScroll() {
        if (window.scrollY > 100) {
            if (!this.state.isShow) {
                this.setState({
                    isShow: true
                });
            }
        } else {
            if (this.state.isShow) {
                this.setState({
                    isShow: false
                });
            }
        }
    }
    goTop() {
        window.scroll({
            top: 0,
            left: 0,
            behavior: "smooth"
        });
    }
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `back-to-top animated ${this.state.isShow ? "fadeIn show" : "fadeOut"}`,
            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "btn btn-lg btn-primary btn-lg-square",
                onClick: ()=>this.goTop(),
                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "mdi mdi-arrow-up"
                })
            })
        });
    }
}

// EXTERNAL MODULE: ./src/library/react/handles/form.tsx
var handles_form = __webpack_require__(627);
;// CONCATENATED MODULE: ./src/services/subscriber.service.ts


/* harmony default export */ const subscriber_service = ({
    add (params) {
        return api/* default.post */.Z.post({
            url: [
                constants/* ServicePages.subscriber */.sm.subscriber
            ],
            data: params
        });
    }
});

;// CONCATENATED MODULE: ./src/components/tools/footer.tsx





class Footer extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            isSubmittingSubscribe: false,
            isSuccessSubscribe: false,
            formData: {
                subscribeForm: {
                    email: ""
                }
            }
        };
    }
    onSubscribe(event) {
        event.preventDefault();
        this.setState({
            isSubmittingSubscribe: true
        }, ()=>{
            subscriber_service.add({
                ...this.state.formData.subscribeForm
            }).then((resData)=>{
                this.setState({
                    isSubmittingSubscribe: false,
                    isSuccessSubscribe: true
                });
            });
        });
    }
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
            id: "footer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "footer-top",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-4 col-md-6 footer-info",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "logo")?.contents?.content
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "desc")?.contents?.content
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-2 col-md-6 footer-links",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "policies")?.contents?.content
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: this.props.pageData.themeTools.footer?.types?.findMulti("elementId", [
                                                "cookie",
                                                "privacy",
                                                "termsOfUse"
                                            ]).map((type)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: link_util/* default.target */.Z.target(this.props.appData, type?.contents?.url || ""),
                                                        children: type?.contents?.content
                                                    })
                                                }))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-3 col-md-6 footer-contact",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "contact")?.contents?.content
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "emailHelp")?.contents?.content,
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "email")?.contents?.content,
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                        href: "https://api.whatsapp.com/send?phone=05451031057",
                                                        target: "_blank",
                                                        className: "text-light",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa fa-whatsapp",
                                                                "aria-hidden": "true"
                                                            }),
                                                            " ",
                                                            this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "whatsapp")?.contents?.content
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "social-links",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "",
                                                    className: "twitter",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-twitter",
                                                        "aria-hidden": "true"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    className: "facebook",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-facebook-official",
                                                        "aria-hidden": "true"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    className: "instagram",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-instagram",
                                                        "aria-hidden": "true"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    className: "google-plus",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-google",
                                                        "aria-hidden": "true"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    className: "linkedin",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-linkedin-square",
                                                        "aria-hidden": "true"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-3 col-md-6 footer-newsletter",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "subscribe")?.contents?.content
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: this.props.pageData.themeTools.footer?.types?.findSingle("elementId", "subscribeDesc")?.contents?.content
                                        }),
                                        !this.state.isSuccessSubscribe ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            onSubmit: (event)=>this.onSubscribe(event),
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "email",
                                                    name: "subscribeForm.email",
                                                    required: true,
                                                    value: this.state.formData.subscribeForm.email,
                                                    onChange: (event)=>handles_form/* default.onChangeInput */.Z.onChangeInput(event, this)
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    disabled: this.state.isSubmittingSubscribe,
                                                    children: this.state.isSubmittingSubscribe ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-spinner fa-spin me-1"
                                                    }) : this.props.pageData.themeTools.footer?.types.findSingle("elementId", "subscribeBtn")?.contents?.content
                                                })
                                            ]
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: this.props.pageData.themeTools.footer?.types.findSingle("elementId", "subscribed")?.contents?.content
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "copyright",
                        children: [
                            "\xa9 Copyright ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "WabbySoft"
                            }),
                            ". All Rights Reserved"
                        ]
                    })
                })
            ]
        });
    }
}

;// CONCATENATED MODULE: ./src/pages/_app.tsx




















function App(props) {
    let data = {
        ...{
            router: props.router,
            ...props.pageProps
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: imageSource_util/* default.getUploadedImageSrc */.Z.getUploadedImageSrc(props.pageProps.appData.settings.icon, props.pageProps.appData.apiPath.uploads)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "canonical",
                        href: props.pageProps.appData.apiPath.website.full
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1.0, width=device-width"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ProviderNoFound, {
                ...data,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ComponentHead, {
                        ...data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {
                        ...data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BackToTop, {
                        ...data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(props.Component, {
                        ...data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {
                        ...data
                    })
                ]
            })
        ]
    });
}
App.getInitialProps = async (props)=>{
    if ( true && props.ctx.req && props.ctx.res) {
        let req = props.ctx.req;
        let res = props.ctx.res;
        res.setHeader("Cache-Control", "public, s-maxage=10, stale-while-revalidate=59");
        req.pageData = {
            ...req.pageData
        };
        req.appData = {
            ...req.appData
        };
        cookie_lib.set(req);
        path_lib.set(req);
        await language_lib.set(req);
        await setting_lib.setDefaultLanguageId(req);
        let langMatches = req.appData.apiPath.website.originalUrl.match(/\/([a-z]{2}\-[a-z]{2})/gm);
        if (langMatches && langMatches.length > 0) {
            let langKey = langMatches[0].slice(1);
            if (language_lib.check(req, res, langKey)) return {};
            cookie_lib.setLanguageId(req, res);
            await setting_lib.set(req);
            if (language_lib.isDefault(req, res)) return {};
        } else {
            if (language_lib.checkCookie(req, res)) return {};
            await setting_lib.set(req);
        }
        await theme_lib/* default.setTools */.Z.setTools(req);
    }
    return {
        pageProps: {
            appData: props.ctx.req?.appData ?? {},
            pageData: props.ctx.req?.pageData ?? {}
        }
    };
};
/* harmony default export */ const _app = (App);


/***/ }),

/***/ 2202:
/***/ (() => {



/***/ }),

/***/ 4208:
/***/ ((module) => {

"use strict";
module.exports = require("cross-fetch/polyfill");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [552,326,402,199], () => (__webpack_exec__(8046)));
module.exports = __webpack_exports__;

})();